"""
Siglip特征投影器实现。
提供特征维度转换和多token生成功能，并保持特征的对比学习性质。
兼容原有projectors.py的接口。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class _MLPVectorProjector(nn.Module):
    """MLP向量投影器
    
    将单个特征向量投影为多个token表示，同时保持特征的对比学习性质。
    
    Attributes:
        mlps: 并行MLP层列表
        norm: 特征归一化层
        attention: 注意力层，用于token间的信息交互
    """
    
    def __init__(
        self,
        input_hidden_size: int,
        lm_hidden_size: int,
        num_layers: int,
        width: int,
        dropout: float = 0.1
    ):
        """初始化投影器
        
        Args:
            input_hidden_size: 输入特征维度
            lm_hidden_size: 语言模型隐藏层维度
            num_layers: MLP层数
            width: 输出token数量
            dropout: Dropout比率
        """
        super().__init__()
        
        # 创建并行MLP
        self.mlps = nn.ModuleList()
        for _ in range(width):
            layers = []
            # 第一层：输入维度转换
            layers.append(nn.Linear(input_hidden_size, lm_hidden_size))
            layers.append(nn.LayerNorm(lm_hidden_size))
            layers.append(nn.GELU())
            layers.append(nn.Dropout(dropout))
            
            # 中间层
            for _ in range(1, num_layers - 1):
                layers.append(nn.Linear(lm_hidden_size, lm_hidden_size))
                layers.append(nn.LayerNorm(lm_hidden_size))
                layers.append(nn.GELU())
                layers.append(nn.Dropout(dropout))
            
            # 最后一层
            if num_layers > 1:
                layers.append(nn.Linear(lm_hidden_size, lm_hidden_size))
                layers.append(nn.LayerNorm(lm_hidden_size))
            
            self.mlps.append(nn.Sequential(*layers))
        
        # 特征归一化
        self.norm = nn.LayerNorm(lm_hidden_size)
        
        # 多头注意力层，用于token间的信息交互
        self.attention = nn.MultiheadAttention(
            embed_dim=lm_hidden_size,
            num_heads=8,
            dropout=dropout,
            batch_first=True
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """前向传播
        
        Args:
            x: 输入特征张量，形状为 [batch_size, 1, input_hidden_size]
            
        Returns:
            输出特征张量，形状为 [batch_size, width, lm_hidden_size]
        """
        # 通过并行MLP生成多个token
        tokens = []
        for mlp in self.mlps:
            tokens.append(mlp(x))
        tokens = torch.cat(tokens, dim=1)  # [batch_size, width, lm_hidden_size]
        
        # 应用注意力机制
        attn_output, _ = self.attention(tokens, tokens, tokens)
        tokens = tokens + attn_output  # 残差连接
        
        # 归一化
        tokens = self.norm(tokens)
        
        return tokens


def build_patch_mlp_projector(
    input_hidden_size: int,
    lm_hidden_size: int,
    num_layers: int
) -> nn.Module:
    """构建单一特征向量投影器
    
    Args:
        input_hidden_size: 输入特征维度
        lm_hidden_size: 语言模型隐藏层维度
        num_layers: MLP层数
        
    Returns:
        投影器模块
    """
    layers = []
    # 第一层
    layers.append(nn.Linear(input_hidden_size, lm_hidden_size))
    layers.append(nn.LayerNorm(lm_hidden_size))
    layers.append(nn.GELU())
    
    # 中间层
    for _ in range(1, num_layers):
        layers.append(nn.Linear(lm_hidden_size, lm_hidden_size))
        layers.append(nn.LayerNorm(lm_hidden_size))
        layers.append(nn.GELU())
    
    return nn.Sequential(*layers)


def build_mlp_vector_projector(
    input_hidden_size: int,
    lm_hidden_size: int,
    num_layers: int,
    num_tokens: int,
    dropout: float = 0.1
) -> nn.Module:
    """构建多token向量投影器
    
    Args:
        input_hidden_size: 输入特征维度
        lm_hidden_size: 语言模型隐藏层维度
        num_layers: MLP层数
        num_tokens: 输出token数量
        dropout: Dropout比率
        
    Returns:
        投影器模块
    """
    return _MLPVectorProjector(
        input_hidden_size=input_hidden_size,
        lm_hidden_size=lm_hidden_size,
        num_layers=num_layers,
        width=num_tokens,
        dropout=dropout
    ) 
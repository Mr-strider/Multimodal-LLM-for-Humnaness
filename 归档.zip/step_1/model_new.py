"""
Siglip模型实现，用于多模态文本-图像对比学习。
该模型使用BERT作为文本编码器，ViT作为图像编码器，通过对比学习的方式学习文本和图像的对齐表示。
"""

from typing import Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from transformers import (
    PreTrainedModel,
    PretrainedConfig,
    AutoModel,
    AutoTokenizer,
    AutoProcessor,
    ModelOutput
)


@dataclass
class SiglipOutput(ModelOutput):
    """Siglip模型输出类
    
    Attributes:
        loss: 对比学习损失值
        logits_per_text: 文本到图像的相似度矩阵
        logits_per_image: 图像到文本的相似度矩阵
        text_embeds: 文本特征向量
        image_embeds: 图像特征向量
    """
    loss: Optional[torch.FloatTensor] = None
    logits_per_text: Optional[torch.FloatTensor] = None
    logits_per_image: Optional[torch.FloatTensor] = None
    text_embeds: Optional[torch.FloatTensor] = None
    image_embeds: Optional[torch.FloatTensor] = None


class SiglipConfig(PretrainedConfig):
    """Siglip模型配置类
    
    Attributes:
        vision_model_name_or_path: 视觉模型的名称或路径
        text_model_name_or_path: 文本模型的名称或路径
        model_type: 模型类型标识符
    """
    model_type = "siglip"

    def __init__(
        self,
        vision_model_name_or_path: str = "vit-base-patch16-224",
        text_model_name_or_path: str = "bert-base-chinese",
        **kwargs
    ) -> None:
        """初始化Siglip配置
        
        Args:
            vision_model_name_or_path: 视觉模型的名称或路径，默认使用ViT base模型
            text_model_name_or_path: 文本模型的名称或路径，默认使用中文BERT
            **kwargs: 其他配置参数
        """
        super().__init__(**kwargs)
        self.vision_model_name_or_path = vision_model_name_or_path
        self.text_model_name_or_path = text_model_name_or_path


class SiglipModel(PreTrainedModel):
    """Siglip模型类
    
    实现了基于BERT和ViT的多模态对比学习模型。
    
    Attributes:
        config_class: 配置类
        vision_model: 视觉编码器
        process: 图像处理器
        text_model: 文本编码器
        tokenizer: 文本分词器
        t: 温度参数
        b: 偏置参数
    """
    config_class = SiglipConfig

    def __init__(self, config: SiglipConfig) -> None:
        """初始化Siglip模型
        
        Args:
            config: 模型配置对象
        """
        super().__init__(config)
        
        # 初始化视觉和文本模型
        self.vision_model = AutoModel.from_pretrained(config.vision_model_name_or_path)
        self.process = AutoProcessor.from_pretrained(config.vision_model_name_or_path)
        self.text_model = AutoModel.from_pretrained(config.text_model_name_or_path)
        self.tokenizer = AutoTokenizer.from_pretrained(config.text_model_name_or_path)
        
        # 初始化可学习参数
        self.t = nn.Parameter(torch.randn(1))  # 温度参数
        self.b = nn.Parameter(torch.randn(1))  # 偏置参数

    def _normalize_features(
        self, 
        features: torch.Tensor, 
        dim: int = -1
    ) -> torch.Tensor:
        """对特征进行L2标准化
        
        Args:
            features: 输入特征张量
            dim: 标准化维度，默认为最后一维
            
        Returns:
            标准化后的特征张量
        """
        return features / features.norm(p=2, dim=dim, keepdim=True)

    def _compute_loss(
        self, 
        logits: torch.Tensor,
        device: torch.device
    ) -> torch.Tensor:
        """计算对比学习损失
        
        使用对数sigmoid损失函数计算正负样本对的损失。
        
        Args:
            logits: 相似度矩阵
            device: 计算设备
            
        Returns:
            计算得到的损失值
        """
        batch_size = logits.shape[0]
        labels = (
            2 * torch.eye(batch_size, device=device) - 
            torch.ones_like(logits, device=device)
        )
        loglik = F.logsigmoid(labels * logits)
        return -torch.sum(loglik, dim=-1).mean()

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        pixel_values: torch.Tensor
    ) -> SiglipOutput:
        """前向传播
        
        Args:
            input_ids: 文本输入ID
            attention_mask: 文本注意力掩码
            pixel_values: 图像像素值
            
        Returns:
            包含损失值和中间结果的SiglipOutput对象
        """
        # 获取文本和图像特征
        text_outputs = self.text_model(input_ids, attention_mask)
        vision_outputs = self.vision_model(pixel_values)
        
        # 提取pooler输出并进行标准化
        vision_features = self._normalize_features(vision_outputs[1])
        text_features = self._normalize_features(text_outputs[1])
        
        # 计算相似度矩阵
        logits_per_text = torch.matmul(text_features, vision_features.t()) * self.t.exp() + self.b
        logits_per_image = logits_per_text.t()
        
        # 计算损失
        loss = self._compute_loss(logits_per_text, logits_per_text.device)
        
        return SiglipOutput(
            loss=loss,
            logits_per_text=logits_per_text,
            logits_per_image=logits_per_image,
            text_embeds=text_features,
            image_embeds=vision_features
        )


if __name__ == '__main__':
    # 测试代码
    config = SiglipConfig()
    model = SiglipModel(config)
    
    # 创建模拟输入
    batch_size = 2
    seq_length = 64
    input_ids = torch.randint(0, 1000, (batch_size, seq_length))
    attention_mask = torch.ones((batch_size, seq_length))
    pixel_values = torch.randn((batch_size, 3, 224, 224))
    
    # 测试前向传播
    outputs = model(input_ids, attention_mask, pixel_values)
    print(f"损失值: {outputs.loss.item()}")
    print(f"文本-图像相似度矩阵形状: {outputs.logits_per_text.shape}") 
"""
Siglip模型训练脚本。
实现了基于Transformers的训练流程，支持混合精度训练、梯度累积和断点续训等功能。
"""

import os
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from pathlib import Path

import torch
from transformers import (
    TrainingArguments,
    Trainer,
    HfArgumentParser,
    set_seed,
)

from model_new import SiglipModel, SiglipConfig
from dataset_new import SiglipDataset, MyDataCollator
from utils import plot_training_loss


@dataclass
class ModelArguments:
    """模型相关的参数配置
    
    Attributes:
        vision_model_path: 视觉模型路径
        text_model_path: 文本模型路径
        model_name_or_path: 预训练模型路径，用于断点续训
    """
    vision_model_path: str = field(
        default="/home/user/wyf/train_siglip_from_scratch/vit-base-patch16-224",
        metadata={"help": "视觉模型路径"}
    )
    text_model_path: str = field(
        default="/home/user/wyf/chinese-roberta-wwm-ext",
        metadata={"help": "文本模型路径"}
    )
    model_name_or_path: Optional[str] = field(
        default=None,
        metadata={"help": "预训练模型路径，用于断点续训"}
    )


@dataclass
class DataArguments:
    """数据集相关的参数配置
    
    Attributes:
        text_data_path: 文本数据路径
        image_data_path: 图像数据路径
        max_seq_length: 最大序列长度
    """
    text_data_path: str = field(
        default="/home/user/wyf/train_siglip_from_scratch/MUGE/all_texts.jsonl",
        metadata={"help": "文本数据路径"}
    )
    image_data_path: str = field(
        default="/home/user/wyf/train_siglip_from_scratch/MUGE/all_imgs.tsv",
        metadata={"help": "图像数据路径"}
    )
    max_seq_length: int = field(
        default=64,
        metadata={"help": "最大序列长度"}
    )


def setup_training_environment() -> None:
    """设置训练环境
    
    配置GPU设备、随机种子等训练环境
    """
    # 设置随机种子
    set_seed(42)
    
    # 设置GPU设备
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True


def get_training_arguments() -> TrainingArguments:
    """获取训练参数配置
    
    Returns:
        训练参数配置对象
    """
    return TrainingArguments(
        output_dir="./outputs",                # 输出目录
        do_train=True,                         # 是否进行训练
        per_device_train_batch_size=32,        # 每个设备的批次大小
        learning_rate=1e-4,                    # 学习率
        num_train_epochs=40,                   # 训练轮数
        save_steps=2000,                       # 保存检查点的步数
        save_total_limit=5,                    # 保存的检查点数量
        fp16=True,                            # 是否使用混合精度训练
        gradient_accumulation_steps=8,         # 梯度累积步数
        logging_steps=100,                     # 日志记录步数
        report_to="none",                      # 不使用外部日志工具
        dataloader_pin_memory=True,            # 数据加载器使用锁页内存
        dataloader_num_workers=1,              # 数据加载器的工作进程数
        # 添加其他训练参数...
    )


def train(
    model_args: ModelArguments,
    data_args: DataArguments,
    training_args: TrainingArguments
) -> None:
    """训练模型
    
    Args:
        model_args: 模型相关参数
        data_args: 数据集相关参数
        training_args: 训练相关参数
    """
    # 初始化模型和配置
    config = SiglipConfig(
        vision_model_name_or_path=model_args.vision_model_path,
        text_model_name_or_path=model_args.text_model_path
    )
    
    if model_args.model_name_or_path:
        model = SiglipModel.from_pretrained(model_args.model_name_or_path, config=config)
    else:
        model = SiglipModel(config)
    
    # 初始化分词器和处理器
    tokenizer = model.tokenizer
    processor = model.process
    
    # 准备数据集
    dataset = SiglipDataset(
        text_data_path=data_args.text_data_path,
        image_data_path=data_args.image_data_path,
        tokenizer=tokenizer,
        processor=processor,
        max_seq_length=data_args.max_seq_length
    )
    
    # 初始化训练器
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        data_collator=MyDataCollator(tokenizer)
    )
    
    # 开始训练
    checkpoint = None
    if training_args.resume_from_checkpoint:
        checkpoint = training_args.resume_from_checkpoint
    
    train_result = trainer.train(resume_from_checkpoint=checkpoint)
    
    # 保存模型和训练状态
    trainer.save_model()
    trainer.save_state()
    
    # 打印训练结果
    print(f"训练完成！训练步数: {train_result.global_step}")
    print(f"训练损失: {train_result.training_loss}")
    
    # 可视化训练损失
    state_path = os.path.join(training_args.output_dir, "trainer_state.json")
    if os.path.exists(state_path):
        plot_training_loss(
            state_path=state_path,
            output_path=os.path.join(training_args.output_dir, "loss_curve.html")
        )


def main():
    """主函数"""
    # 解析命令行参数
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainingArguments))
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    
    # 设置训练环境
    setup_training_environment()
    
    # 开始训练
    train(model_args, data_args, training_args)


if __name__ == "__main__":
    main() 
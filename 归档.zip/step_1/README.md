# Siglip 多模态模型训练项目

本项目实现了一个基于BERT和ViT的多模态对比学习模型，用于学习文本和图像之间的对齐表示。该实现参考了Siglip的思想，使用对比学习的方式训练文本-图像对。

## 项目结构

```
train_siglip_from_scratch/
├── README.md               # 项目说明文档
├── dataset_new.py         # 数据集实现
├── model_new.py           # 模型实现
├── train_new.py           # 训练脚本
├── test_model.py          # 测试和推理脚本
└── utils.py               # 工具函数
```

## 功能特点

- 基于Transformers库实现，支持最新的预训练模型
- 使用BERT作为文本编码器，ViT作为图像编码器
- 实现了对比学习的损失函数
- 支持混合精度训练(FP16)
- 支持梯度累积
- 支持断点续训
- 支持多GPU训练
- 完整的类型提示和文档字符串
- 提供便捷的模型测试和推理接口

## 环境要求

- Python 3.7+
- PyTorch 1.10+
- Transformers 4.20+
- 其他依赖：
  ```
  torch
  transformers
  pandas
  pillow
  requests
  plotly
  ```

## 安装步骤

1. 克隆项目：
```bash
git clone [项目地址]
cd train_siglip_from_scratch
```

2. 创建虚拟环境（推荐）：
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
.\venv\Scripts\activate  # Windows
```

3. 安装依赖：
```bash
pip install -r requirements.txt
```

## 数据准备

1. 准备文本数据：
   - 格式：JSONL文件
   - 每行包含：`{"text": "文本描述", "image_ids": ["图像ID1", "图像ID2", ...]}`

2. 准备图像数据：
   - 格式：TSV文件
   - 列：`image_id\tbase64_encoded_image`

## 使用方法

### 基本训练

使用默认参数进行训练：

```bash
python train_new.py
```

### 自定义训练参数

可以通过命令行参数自定义训练配置：

```bash
python train_new.py \
    --vision_model_path /path/to/vision/model \
    --text_model_path /path/to/text/model \
    --text_data_path /path/to/text/data.jsonl \
    --image_data_path /path/to/image/data.tsv \
    --output_dir ./custom_outputs \
    --learning_rate 2e-4 \
    --num_train_epochs 50 \
    --per_device_train_batch_size 16 \
    --gradient_accumulation_steps 4
```

### 模型测试和推理

使用 `test_model.py` 进行模型测试和推理：

```python
from test_model import SiglipPredictor

# 初始化预测器
predictor = SiglipPredictor(
    model_path='path/to/model',
    processor_path='path/to/processor',
    tokenizer_path='path/to/tokenizer'
)

# 使用URL图像进行预测
image_url = "http://example.com/image.jpg"
texts = ["图像描述1", "图像描述2"]
predictor.print_predictions(image_url, texts)

# 使用本地图像进行预测
local_image = "path/to/local/image.jpg"
predictor.print_predictions(local_image, texts)
```

也可以直接运行测试脚本：

```bash
python test_model.py
```

### 主要参数说明

#### 模型参数
- `--vision_model_path`: 视觉模型路径
- `--text_model_path`: 文本模型路径
- `--model_name_or_path`: 预训练模型路径（用于断点续训）

#### 数据参数
- `--text_data_path`: 文本数据路径
- `--image_data_path`: 图像数据路径
- `--max_seq_length`: 最大序列长度

#### 训练参数
- `--output_dir`: 输出目录
- `--learning_rate`: 学习率
- `--num_train_epochs`: 训练轮数
- `--per_device_train_batch_size`: 每个设备的批次大小
- `--gradient_accumulation_steps`: 梯度累积步数
- `--fp16`: 是否使用混合精度训练
- `--save_steps`: 保存检查点的步数
- `--save_total_limit`: 保存的检查点数量

## 训练监控

训练过程中会输出以下信息：
- 训练损失
- 学习率
- 训练速度（样本/秒）
- GPU内存使用情况

可以使用 `utils.py` 中的 `plot_training_loss` 函数可视化训练损失：

```python
from utils import plot_training_loss

plot_training_loss(
    state_path='outputs/trainer_state.json',
    output_path='loss_curve.html'
)
```

## 模型保存

模型会在以下情况下保存：
1. 达到指定的保存步数（`save_steps`）
2. 训练完成时

保存的内容包括：
- 模型权重
- 训练状态
- 优化器状态（用于断点续训）

## 注意事项

1. 数据准备：
   - 确保文本数据和图像数据的ID对应关系正确
   - 图像数据需要正确编码为base64格式

2. 内存管理：
   - 根据GPU显存大小调整batch_size
   - 如果显存不足，可以增加梯度累积步数

3. 训练优化：
   - 可以通过调整学习率和训练轮数来优化训练效果
   - 使用混合精度训练可以显著减少显存使用

4. 推理注意事项：
   - 确保模型路径正确
   - 推理时使用相同的预处理参数
   - 对于大量图像的批量推理，建议使用GPU加速

## 常见问题

1. 显存不足：
   - 减小batch_size
   - 增加gradient_accumulation_steps
   - 启用fp16训练

2. 训练速度慢：
   - 增加dataloader_num_workers
   - 确保使用GPU训练
   - 检查数据加载瓶颈

3. 断点续训：
   - 使用`--model_name_or_path`指定检查点路径
   - 确保检查点包含完整的模型状态

4. 推理问题：
   - 检查模型加载路径
   - 确认输入图像格式
   - 验证文本长度限制

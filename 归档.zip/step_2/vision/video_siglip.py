"""
基于Siglip的图像-文本对比学习模块。
提供图像编码和文本编码功能。
"""

from typing import Dict, List, Optional, Union, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoProcessor, AutoModel, AutoTokenizer

from step_2.vision.base_modality import Modality
from step_2.vision.siglip_projectors import build_mlp_vector_projector


OUTPUT_EMB_SIZE = 768  # BERT和ViT的输出维度


class SiglipModule(nn.Module):
    """Siglip模型模块
    
    用于图像-文本对比学习的核心模块。
    
    Attributes:
        vision_model: 视觉编码器
        text_model: 文本编码器
        processor: 图像处理器
        tokenizer: 文本分词器
        t: 温度参数
        b: 偏置参数
    """
    
    def __init__(
        self,
        vision_model_path: str,
        text_model_path: str
    ) -> None:
        """初始化Siglip模块
        
        Args:
            vision_model_path: 视觉模型路径
            text_model_path: 文本模型路径
        """
        super().__init__()
        
        # 加载模型和处理器
        self.vision_model = AutoModel.from_pretrained(vision_model_path)
        self.text_model = AutoModel.from_pretrained(text_model_path)
        self.processor = AutoProcessor.from_pretrained(vision_model_path)
        self.tokenizer = AutoTokenizer.from_pretrained(text_model_path)
        
        # 初始化可学习参数
        self.t = nn.Parameter(torch.randn(1))
        self.b = nn.Parameter(torch.randn(1))
        
        # 冻结基础模型参数
        self.vision_model.requires_grad_(False)
        self.text_model.requires_grad_(False)
    
    def _normalize_features(
        self,
        features: torch.Tensor,
        dim: int = -1
    ) -> torch.Tensor:
        """对特征进行L2标准化
        
        Args:
            features: 输入特征张量
            dim: 标准化维度
            
        Returns:
            标准化后的特征张量
        """
        return features / features.norm(p=2, dim=dim, keepdim=True)
    
    @torch.no_grad()
    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        pixel_values: Optional[torch.Tensor] = None
    ) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
        """前向传播
        
        Args:
            input_ids: 文本输入ID
            attention_mask: 文本注意力掩码
            pixel_values: 图像像素值
            
        Returns:
            文本特征和图像特征的元组
        """
        text_features = None
        image_features = None
        
        # 处理文本输入
        if input_ids is not None and attention_mask is not None:
            text_outputs = self.text_model(input_ids, attention_mask)
            text_features = self._normalize_features(text_outputs[1])
        
        # 处理图像输入
        if pixel_values is not None:
            vision_outputs = self.vision_model(pixel_values)
            image_features = self._normalize_features(vision_outputs[1])
        
        return text_features, image_features
    
    def compute_similarity(
        self,
        text_features: torch.Tensor,
        image_features: torch.Tensor
    ) -> torch.Tensor:
        """计算文本-图像相似度
        
        Args:
            text_features: 文本特征
            image_features: 图像特征
            
        Returns:
            相似度矩阵
        """
        return torch.matmul(text_features, image_features.t()) * self.t.exp() + self.b
    
    @property
    def dtype(self) -> torch.dtype:
        """返回模型数据类型"""
        return self.vision_model.dtype
    
    @property
    def device(self) -> torch.device:
        """返回模型设备"""
        return self.vision_model.device


class SiglipModality(Modality):
    """Siglip模态处理类
    
    用于处理图像输入并生成对应的特征表示。
    """
    
    def __init__(
        self,
        vision_model_path: str = "openai/clip-vit-base-patch32",
        text_model_path: str = "bert-base-chinese",
        num_projector_layers: int = 2,
        num_tokens_output: int = 10,
    ):
        """初始化Siglip模态
        
        Args:
            vision_model_path: 视觉模型路径
            text_model_path: 文本模型路径
            num_projector_layers: 投影层数量
            num_tokens_output: 输出token数量
        """
        self.vision_model_path = vision_model_path
        self.text_model_path = text_model_path
        self.module = SiglipModule(
            vision_model_path=vision_model_path,
            text_model_path=text_model_path
        )
        self.num_projector_layers = num_projector_layers
        self.num_tokens_output = num_tokens_output
    
    def build_projector(self, lm_hidden_size: int) -> nn.Module:
        """构建特征投影器
        
        Args:
            lm_hidden_size: 语言模型隐藏层大小
            
        Returns:
            投影器模块
        """
        return build_mlp_vector_projector(
            input_hidden_size=OUTPUT_EMB_SIZE,
            lm_hidden_size=lm_hidden_size,
            num_layers=self.num_projector_layers,
            num_tokens=self.num_tokens_output,
        )
    
    @property
    def name(self) -> str:
        """返回模态名称"""
        return "image_siglip"
    
    @property
    def token(self) -> str:
        """返回模态token"""
        return "<image>"
    
    @property
    def data_key(self) -> str:
        """返回数据键名"""
        return "images"
    
    @property
    def token_width(self) -> int:
        """返回token宽度"""
        return self.num_tokens_output
    
    def to(self, dtype: torch.dtype, device: torch.device) -> "SiglipModality":
        """移动模型到指定设备和数据类型
        
        Args:
            dtype: 目标数据类型
            device: 目标设备
            
        Returns:
            当前实例
        """
        self.module.to(dtype=dtype, device=device)
        return self
    
    def preprocess_rows(self, rows: List[Dict]) -> List[Optional[Dict]]:
        """预处理输入数据
        
        Args:
            rows: 输入数据行
            
        Returns:
            处理后的数据列表
        """
        row_values = []
        for row in rows:
            images = row[self.data_key]
            pixel_values = self.module.processor(
                images=images,
                return_tensors="pt",
                padding=True,
            )['pixel_values']
            row_values.append(pixel_values)
        return row_values
    
    @torch.no_grad()
    def forward(self, encoded_values: List[torch.Tensor]) -> List[torch.Tensor]:
        """前向传播
        
        Args:
            encoded_values: 编码后的输入值列表
            
        Returns:
            特征向量列表
        """
        image_features = []
        for pixel_values in encoded_values:
            _, features = self.module.forward(pixel_values=pixel_values)
            image_features.append(features.view(-1, 1, OUTPUT_EMB_SIZE))
        return image_features 
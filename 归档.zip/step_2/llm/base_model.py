from typing import List, Dict
from abc import ABC, abstractmethod

from torch.nn.functional import conv1d
import torch
import logging

from step_2.vision.base_modality import Modality


class LMMMetaModel:
    """大语言多模态模型的基础元类
    
    该类提供了多模态模型的基本功能实现,包括:
    - 权重加载
    - 模态投影器初始化
    - 预训练模块初始化
    """
    
    def __init__(self, config):
        """初始化模型
        
        Args:
            config: 模型配置对象
        """
        super(LMMMetaModel, self).__init__(config)

    def _load_projector_weights(self, weights: Dict):
        """加载投影器权重
        
        Args:
            weights: 包含模型权重的字典
        
        Raises:
            AssertionError: 当存在未预期的权重键时抛出
        """
        # 处理权重键,移除可能的前缀
        weights = {
            (k[23:] if k.startswith("base_model.model.model.") else k): v
            for k, v in weights.items()
        }
        logging.info(f"正在加载预训练权重: {list(weights.keys())}")
        load_result = self.load_state_dict(weights, strict=False)
        assert len(load_result.unexpected_keys) == 0, "发现未预期的权重,请检查模型是否正确"

    def initialize_pretrained_modules(self, modalities: List[Modality], weights: Dict):
        """初始化预训练模块
        
        Args:
            modalities: 模态对象列表
            weights: 预训练权重字典
        """
        for modality in modalities:
            projector = modality.build_projector(self.config.hidden_size)
            setattr(self, modality.name + "_lmm_projector", projector)

        self._load_projector_weights(weights)

    def initialize_modules(self, modalities: List[Modality], weights: Dict):
        """初始化所有模块
        
        Args:
            modalities: 模态对象列表
            weights: 模型权重字典
        """
        names = [modality.name for modality in modalities]
        self.config.modalities = names

        for modality in modalities:
            projector = modality.build_projector(self.config.hidden_size)
            setattr(self, modality.name + "_lmm_projector", projector)

        self._load_projector_weights(weights)


class LMMMetaForCausalLM(ABC):
    """因果语言模型的多模态元类
    
    提供多模态输入处理的基础实现
    """
    
    @abstractmethod
    def get_model(self) -> "LMMMetaForCausalLM":
        """获取模型实例的抽象方法"""
        pass

    def prepare_inputs_labels_for_multimodal(
        self, 
        input_ids, 
        attention_mask, 
        past_key_values, 
        labels, 
        **kwargs
    ):
        """准备多模态输入和标签
        
        处理文本和其他模态的输入,将它们转换为模型可用的嵌入表示
        
        Args:
            input_ids: 输入token的ID
            attention_mask: 注意力掩码
            past_key_values: 过去的键值对(用于缓存)
            labels: 标签
            **kwargs: 其他模态的输入数据
            
        Returns:
            tuple: (None, attention_mask, past_key_values, inputs_embeds, labels)
        """
        model = self.get_model()
        batch_size, seq_len = input_ids.shape

        # 初始化输入嵌入张量
        inputs_embeds = torch.zeros(
            (batch_size, seq_len, self.config.hidden_size),
            dtype=self.dtype,
            device=self.device,
        )

        # 存储各个模态的投影张量
        projected_tensors = []
        
        # 如果没有缓存的key-value,则需要编码指令模态值
        if past_key_values is None:
            for modality in self.modalities:
                modality_values = modality.forward(kwargs.get(modality.name))
                projected_values = []
                projector = getattr(model, modality.name + "_lmm_projector")

                # 将每个批次投影到语言模型的token空间
                for modality_value in modality_values:
                    projected_values.append(projector(modality_value))

                # 验证投影后的张量形状是否正确
                assert all(
                    proj_val.shape[1:] == (modality.token_width, self.config.hidden_size)
                    for proj_val in projected_values
                ), (
                    f"模态张量形状不正确,请检查投影器实现。"
                    f"当前形状: {[proj_val.shape[1:] for proj_val in projected_values]}, "
                    f"期望形状: {(modality.token_width, self.config.hidden_size)}"
                )
                projected_tensors.append(projected_values)

        # 处理每个样本
        for i, input_ids_sample in enumerate(input_ids):
            # 识别文本token的位置
            is_text_mask = input_ids_sample >= 0

            # 填充语言模型的文本嵌入
            inputs_embeds[i, is_text_mask] = model.embed_tokens(
                input_ids_sample[is_text_mask]
            )

            # 如果全是文本token则跳过
            if is_text_mask.sum() == seq_len:
                continue
                
            assert past_key_values is None, "首次指令处理时不应该有缓存的键值对"

            # 处理每个模态
            for mi, modality in enumerate(self.modalities):
                # 定位该模态的token组
                modality_mask = (input_ids_sample == modality.token_idx).float()
                modality_kernel = torch.tensor(
                    [-1] * modality.token_width, 
                    dtype=modality_mask.dtype, 
                    device=modality_mask.device
                )
                modality_conv = conv1d(
                    modality_mask.unsqueeze(0).unsqueeze(0),
                    modality_kernel.unsqueeze(0).unsqueeze(0),
                )

                # 找出连续token_width个token的位置
                indices = (modality_conv[0, 0] == -modality.token_width).nonzero(as_tuple=True)[0]

                # 用投影后的模态张量填充这些位置
                last_covered_idx = -1
                k = 0
                for possible_token_idx in indices:
                    if possible_token_idx <= last_covered_idx:
                        # 避免覆盖已处理的实例(处理连续token的情况)
                        continue
                    batch_modality_tensor = projected_tensors[mi][i][k]
                    inputs_embeds[
                        i, 
                        possible_token_idx : possible_token_idx + modality.token_width
                    ] = batch_modality_tensor
                    last_covered_idx = possible_token_idx + modality.token_width - 1
                    k += 1

        return None, attention_mask, past_key_values, inputs_embeds, labels

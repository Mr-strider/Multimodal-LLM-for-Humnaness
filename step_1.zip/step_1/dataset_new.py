"""
多模态数据集实现，用于加载和处理文本-图像对数据。
支持从jsonl文件加载文本数据和从tsv文件加载base64编码的图像数据。
"""

from typing import Dict, List, Any
import json
import random
from io import BytesIO
import base64

import torch
from torch.utils.data import Dataset
import pandas as pd
from PIL import Image
from transformers import PreTrainedTokenizer, AutoProcessor


class SiglipDataset(Dataset):
    """Siglip多模态数据集类
    
    用于加载和处理文本-图像对数据的数据集实现。
    
    Attributes:
        text_data_path: jsonl格式文本数据路径
        image_data_path: tsv格式图像数据路径
        tokenizer: 用于文本编码的分词器
        processor: 用于图像处理的处理器
        max_seq_length: 文本序列最大长度
        datas: 数据样本列表
        images: 图像数据DataFrame
    """
    
    def __init__(
        self,
        text_data_path: str,
        image_data_path: str,
        tokenizer: PreTrainedTokenizer,
        processor: AutoProcessor,
        max_seq_length: int = 64,
    ) -> None:
        """初始化数据集
        
        Args:
            text_data_path: jsonl格式文本数据路径
            image_data_path: tsv格式图像数据路径 
            tokenizer: 用于文本编码的分词器
            processor: 用于图像处理的处理器
            max_seq_length: 文本序列最大长度，默认64
        """
        super().__init__()
        self.text_data_path = text_data_path
        self.image_data_path = image_data_path
        self.tokenizer = tokenizer
        self.processor = processor
        self.max_seq_length = max_seq_length
        
        # 加载文本数据
        self.datas = self._load_text_data()
        random.shuffle(self.datas)
        
        # 加载图像数据
        self.images = pd.read_csv(self.image_data_path, sep='\t', header=None)
    
    def _load_text_data(self) -> List[Dict[str, str]]:
        """加载文本数据
        
        从jsonl文件中加载文本数据，并展开image_ids
        
        Returns:
            包含image_id和text的字典列表
        """
        datas = []
        with open(self.text_data_path, 'r', encoding='utf-8') as f:
            for line in f:
                item = json.loads(line)
                for image_id in item['image_ids']:
                    datas.append({'image_id': image_id, 'text': item['text']})
        return datas

    def __getitem__(self, index: int) -> Dict[str, torch.Tensor]:
        """获取数据样本
        
        Args:
            index: 样本索引
            
        Returns:
            包含input_ids、attention_mask和pixel_values的字典
        """
        sample = self.datas[index]
        
        # 处理文本
        text_features = self.tokenizer(
            sample['text'],
            max_length=self.max_seq_length,
            padding='max_length',
            truncation=True
        )
        
        # 处理图像
        image_base64 = self.images[self.images[0] == sample['image_id']][1].values[0]
        image_bytes = base64.b64decode(image_base64)
        image = Image.open(BytesIO(image_bytes)).convert("RGB")
        pixel_values = self.processor(images=image, return_tensors='pt')['pixel_values']
        
        return {
            'input_ids': text_features['input_ids'],
            'attention_mask': text_features['attention_mask'],
            'pixel_values': pixel_values
        }
    
    def __len__(self) -> int:
        """返回数据集大小"""
        return len(self.datas)


class MyDataCollator:
    """数据整理器类
    
    用于将多个样本整理成batch
    
    Attributes:
        tokenizer: 分词器实例
    """
    
    def __init__(self, tokenizer: PreTrainedTokenizer) -> None:
        """初始化数据整理器
        
        Args:
            tokenizer: 分词器实例
        """
        self.tokenizer = tokenizer
    
    def __call__(self, features: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """将多个样本整理成batch
        
        Args:
            features: 样本列表
            
        Returns:
            包含批处理后的input_ids、attention_mask和pixel_values的字典
        """
        input_ids = [f['input_ids'] for f in features]
        attention_mask = [f['attention_mask'] for f in features]
        pixel_values = [f['pixel_values'] for f in features]
        
        return {
            'input_ids': torch.tensor(input_ids),
            'attention_mask': torch.tensor(attention_mask),
            'pixel_values': torch.cat(pixel_values, dim=0)
        }


if __name__ == '__main__':
    from transformers import AutoTokenizer, AutoProcessor
    
    # 测试代码
    tokenizer = AutoTokenizer.from_pretrained('/home/chinese-roberta-wwm-ext')
    processor = AutoProcessor.from_pretrained('/home/vit-base-patch16-224')
    
    dataset = SiglipDataset(
        text_data_path='/home/MUGE/all_texts.jsonl',
        image_data_path='/home/MUGE/all_imgs.tsv',
        tokenizer=tokenizer,
        processor=processor,
        max_seq_length=64
    )
    
    print(f"数据集大小: {len(dataset)}")
    print(f"样本示例: {dataset[2]}") 
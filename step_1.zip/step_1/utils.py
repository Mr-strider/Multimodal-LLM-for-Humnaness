"""
数据处理和可视化工具函数。
提供数据集合并、训练损失可视化等功能。
"""

from typing import List, Tuple, Dict, Any
import json
import pandas as pd
import plotly.express as px
from pathlib import Path


def merge_text_datasets(
    train_path: str,
    valid_path: str,
    test_path: str,
    output_path: str
) -> None:
    """合并训练、验证和测试集的文本数据
    
    Args:
        train_path: 训练集文本数据路径
        valid_path: 验证集文本数据路径
        test_path: 测试集文本数据路径
        output_path: 合并后的输出文件路径
    """
    # 读取各个数据集
    text_data = []
    for file_path in [train_path, valid_path, test_path]:
        with open(file_path, 'r', encoding='utf-8') as f:
            text_data.extend(f.readlines())
    
    # 写入合并后的文件
    with open(output_path, 'w', encoding='utf-8') as f:
        f.writelines(text_data)


def analyze_text_data(jsonl_path: str) -> None:
    """分析文本数据集的统计信息
    
    Args:
        jsonl_path: JSONL格式的文本数据路径
    """
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        for line in f:
            data = json.loads(line)
            if len(data['image_ids']) > 10:
                print(data)


def plot_training_loss(
    state_path: str,
    output_path: str = None,
    width: int = 600,
    height: int = 400
) -> None:
    """可视化训练损失曲线
    
    Args:
        state_path: 训练状态文件路径
        output_path: 图表保存路径，如果为None则显示图表
        width: 图表宽度
        height: 图表高度
    """
    # 读取训练状态
    with open(state_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        log_history = data['log_history']
    
    # 提取步数和损失值
    steps = []
    losses = []
    for log in log_history[:-1]:  # 最后一个记录通常是评估结果，跳过
        steps.append(log['step'])
        losses.append(log['loss'])
    
    # 创建数据框
    df = pd.DataFrame({
        'step': steps,
        'loss': losses
    })
    
    # 绘制损失曲线
    fig = px.line(
        df,
        x='step',
        y='loss',
        title='训练损失变化',
        labels={'step': '训练步数', 'loss': '损失值'}
    )
    
    # 设置图表大小
    fig.update_layout(width=width, height=height)
    
    # 保存或显示图表
    if output_path:
        fig.write_html(output_path)
    else:
        fig.show()


def load_image_data(tsv_path: str) -> pd.DataFrame:
    """加载图像数据
    
    Args:
        tsv_path: TSV格式的图像数据路径
        
    Returns:
        包含图像ID和base64编码的DataFrame
    """
    return pd.read_csv(tsv_path, sep='\t', header=None)


if __name__ == '__main__':
    # 示例用法
    data_dir = Path('/home/user/wyf/train_siglip_from_scratch/MUGE')
    
    # 合并文本数据集
    merge_text_datasets(
        train_path=str(data_dir / 'train_texts.jsonl'),
        valid_path=str(data_dir / 'valid_texts.jsonl'),
        test_path=str(data_dir / 'test_texts.jsonl'),
        output_path=str(data_dir / 'all_texts.jsonl')
    )
    
    # 分析文本数据
    analyze_text_data(str(data_dir / 'all_texts.jsonl'))
    
    # 可视化训练损失
    plot_training_loss(
        state_path='/home/user/wyf/train_siglip_from_scratch/outputs/trainer_state.json',
        output_path='loss_curve.html'
    ) 
"""
Siglip模型测试脚本。
提供模型加载、图像文本匹配推理等功能。
"""

import os
from typing import List, Union, Tuple
from pathlib import Path

import torch
import requests
from PIL import Image
from transformers import AutoProcessor, AutoModel, AutoTokenizer


class SiglipPredictor:
    """Siglip模型预测器
    
    用于加载训练好的模型并进行图像-文本匹配预测。
    
    Attributes:
        processor: 图像处理器
        tokenizer: 文本分词器
        model: Siglip模型
        device: 计算设备
    """
    
    def __init__(
        self,
        model_path: Union[str, Path],
        processor_path: Union[str, Path],
        tokenizer_path: Union[str, Path],
        device: str = None
    ) -> None:
        """初始化预测器
        
        Args:
            model_path: 模型路径
            processor_path: 图像处理器路径
            tokenizer_path: 分词器路径
            device: 计算设备，如果为None则自动选择
        """
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 加载模型和处理器
        self.processor = AutoProcessor.from_pretrained(processor_path)
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
        self.model = AutoModel.from_pretrained(model_path).to(self.device)
        self.model.eval()
    
    def load_image(self, image_source: Union[str, Image.Image]) -> Image.Image:
        """加载图像
        
        Args:
            image_source: 图像源，可以是URL、本地路径或PIL图像对象
            
        Returns:
            PIL图像对象
        """
        if isinstance(image_source, str):
            if image_source.startswith('http'):
                return Image.open(requests.get(image_source, stream=True).raw)
            else:
                return Image.open(image_source)
        return image_source
    
    def process_inputs(
        self,
        image: Union[str, Image.Image],
        texts: List[str],
        max_length: int = 64
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """处理输入数据
        
        Args:
            image: 图像源
            texts: 候选文本列表
            max_length: 文本最大长度
            
        Returns:
            处理后的输入ID、注意力掩码和图像特征
        """
        # 处理图像
        image = self.load_image(image)
        pixel_values = self.processor(images=image, return_tensors="pt")['pixel_values'].to(self.device)
        
        # 处理文本
        text_inputs = self.tokenizer(
            texts,
            padding="max_length",
            max_length=max_length,
            return_tensors="pt"
        )
        input_ids = text_inputs['input_ids'].to(self.device)
        attention_mask = text_inputs['attention_mask'].to(self.device)
        
        return input_ids, attention_mask, pixel_values
    
    @torch.no_grad()
    def predict(
        self,
        image: Union[str, Image.Image],
        texts: List[str],
        max_length: int = 64
    ) -> torch.Tensor:
        """预测图像-文本匹配概率
        
        Args:
            image: 图像源
            texts: 候选文本列表
            max_length: 文本最大长度
            
        Returns:
            匹配概率张量
        """
        # 处理输入
        input_ids, attention_mask, pixel_values = self.process_inputs(
            image, texts, max_length
        )
        
        # 模型推理
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            pixel_values=pixel_values
        )
        
        # 计算概率
        logits_per_image = outputs.logits_per_image
        probs = torch.sigmoid(logits_per_image)
        
        return probs
    
    def print_predictions(
        self,
        image: Union[str, Image.Image],
        texts: List[str],
        max_length: int = 64
    ) -> None:
        """打印预测结果
        
        Args:
            image: 图像源
            texts: 候选文本列表
            max_length: 文本最大长度
        """
        probs = self.predict(image, texts, max_length)
        
        print("预测结果:")
        for i, (text, prob) in enumerate(zip(texts, probs[0])):
            print(f"{prob:.1%} 的概率图像描述为 '{text}'")


def main():
    """主函数"""
    # 模型路径
    model_path = '/home/user/wyf/train_siglip_from_scratch/outputs'
    processor_path = '/home/user/wyf/train_siglip_from_scratch/vit-base-patch16-224'
    tokenizer_path = '/home/user/wyf/chinese-roberta-wwm-ext'
    
    # 初始化预测器
    predictor = SiglipPredictor(
        model_path=model_path,
        processor_path=processor_path,
        tokenizer_path=tokenizer_path
    )
    
    # 测试图像
    image_url = "http://images.cocodataset.org/val2017/000000039769.jpg"
    texts = ["两只猫在玩耍", "一颗树"]
    
    # 进行预测
    predictor.print_predictions(image_url, texts)


if __name__ == "__main__":
    main() 